//
//  EventInfo.swift
//  Assignment_04
//
//  Created by Ravi Rachamalla on 2020-11-24.
//

import Foundation

// create a struct for use with the collection view, will contain
// the eventTitle and eventDate from the API as title and date
// maybe unneccessary for my needs **** CONFIRM WITH SEB *****
struct EventInfo {
    var title: String
    var Date: String
}
