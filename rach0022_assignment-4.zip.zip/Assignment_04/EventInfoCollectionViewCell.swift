//
//  EventInfoCollectionViewCell.swift
//  Assignment_04
//
//  Created by Ravi Rachamalla on 2020-11-24.
//

import UIKit

class EventInfoCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var cellEventTitle: UILabel!
    @IBOutlet weak var cellEventDate: UILabel!
}
